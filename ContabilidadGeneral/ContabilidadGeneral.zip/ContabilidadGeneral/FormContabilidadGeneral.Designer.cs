﻿namespace ContabilidadGeneral
{
    partial class FormContabilidadGeneral
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormContabilidadGeneral));
            this.btnAgregarCuenta = new System.Windows.Forms.Button();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.dgvAsientosContables = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbNumAsiento = new System.Windows.Forms.TextBox();
            this.tbComentario = new System.Windows.Forms.TextBox();
            this.cbTipoCuenta = new System.Windows.Forms.ComboBox();
            this.cbCuenta = new System.Windows.Forms.ComboBox();
            this.tbCantidad = new System.Windows.Forms.TextBox();
            this.gbAgregarCuentaAAsiento = new System.Windows.Forms.GroupBox();
            this.btLimpiarAsiento = new System.Windows.Forms.Button();
            this.btLimipiar = new System.Windows.Forms.Button();
            this.btEliminar = new System.Windows.Forms.Button();
            this.btActualizarCuenta = new System.Windows.Forms.Button();
            this.rbHaber = new System.Windows.Forms.RadioButton();
            this.rbDebe = new System.Windows.Forms.RadioButton();
            this.dgvCuentasT = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbCuentasT = new System.Windows.Forms.TextBox();
            this.gbInfoGeneral = new System.Windows.Forms.GroupBox();
            this.dtpFechaFin = new System.Windows.Forms.DateTimePicker();
            this.dtpFechaInicio = new System.Windows.Forms.DateTimePicker();
            this.tbEmpresa = new System.Windows.Forms.TextBox();
            this.tbEdoRes = new System.Windows.Forms.TextBox();
            this.dgvEdoResultados = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbBalGral = new System.Windows.Forms.TextBox();
            this.dgvBalanceGeneral = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbRazonesFinancieras = new System.Windows.Forms.TextBox();
            this.btImprimirTexto = new System.Windows.Forms.Button();
            this.btEjemplo = new System.Windows.Forms.Button();
            this.btInfo = new System.Windows.Forms.Button();
            this.btAbrirContaCostos = new System.Windows.Forms.Button();
            this.dgvRazonesFinancieras = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbInventarioFinal = new System.Windows.Forms.TextBox();
            this.tbInventarioInicial = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAsientosContables)).BeginInit();
            this.gbAgregarCuentaAAsiento.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCuentasT)).BeginInit();
            this.gbInfoGeneral.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEdoResultados)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBalanceGeneral)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRazonesFinancieras)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAgregarCuenta
            // 
            this.btnAgregarCuenta.Location = new System.Drawing.Point(287, 104);
            this.btnAgregarCuenta.Name = "btnAgregarCuenta";
            this.btnAgregarCuenta.Size = new System.Drawing.Size(117, 31);
            this.btnAgregarCuenta.TabIndex = 5;
            this.btnAgregarCuenta.Text = "Agregar";
            this.btnAgregarCuenta.UseVisualStyleBackColor = true;
            this.btnAgregarCuenta.Click += new System.EventHandler(this.btnAgregarCuenta_Click);
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.ForeColor = System.Drawing.Color.Beige;
            this.btnCalcular.Location = new System.Drawing.Point(413, 3);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(139, 62);
            this.btnCalcular.TabIndex = 1;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // dgvAsientosContables
            // 
            this.dgvAsientosContables.AllowUserToAddRows = false;
            this.dgvAsientosContables.AllowUserToDeleteRows = false;
            this.dgvAsientosContables.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dgvAsientosContables.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAsientosContables.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAsientosContables.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.dgvAsientosContables.Location = new System.Drawing.Point(3, 236);
            this.dgvAsientosContables.MultiSelect = false;
            this.dgvAsientosContables.Name = "dgvAsientosContables";
            this.dgvAsientosContables.ReadOnly = true;
            this.dgvAsientosContables.RowHeadersVisible = false;
            this.dgvAsientosContables.RowTemplate.Height = 24;
            this.dgvAsientosContables.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAsientosContables.Size = new System.Drawing.Size(553, 141);
            this.dgvAsientosContables.TabIndex = 2;
            this.dgvAsientosContables.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAsientosContables_CellClick);
            // 
            // Column1
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle1;
            this.Column1.FillWeight = 50F;
            this.Column1.HeaderText = "Asiento";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.FillWeight = 30F;
            this.Column2.HeaderText = "Comentario";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.FillWeight = 70F;
            this.Column3.HeaderText = "Tipo";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Column4
            // 
            this.Column4.FillWeight = 120F;
            this.Column4.HeaderText = "Cuenta";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Column5.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column5.FillWeight = 75F;
            this.Column5.HeaderText = "Debe";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Column6.DefaultCellStyle = dataGridViewCellStyle3;
            this.Column6.FillWeight = 75F;
            this.Column6.HeaderText = "Haber";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // tbNumAsiento
            // 
            this.tbNumAsiento.Location = new System.Drawing.Point(6, 27);
            this.tbNumAsiento.Name = "tbNumAsiento";
            this.tbNumAsiento.Size = new System.Drawing.Size(82, 22);
            this.tbNumAsiento.TabIndex = 0;
            this.tbNumAsiento.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbComentario
            // 
            this.tbComentario.Location = new System.Drawing.Point(92, 27);
            this.tbComentario.Name = "tbComentario";
            this.tbComentario.Size = new System.Drawing.Size(189, 22);
            this.tbComentario.TabIndex = 4;
            // 
            // cbTipoCuenta
            // 
            this.cbTipoCuenta.FormattingEnabled = true;
            this.cbTipoCuenta.Items.AddRange(new object[] {
            "BalanceGral",
            "EdoResultados"});
            this.cbTipoCuenta.Location = new System.Drawing.Point(6, 74);
            this.cbTipoCuenta.Name = "cbTipoCuenta";
            this.cbTipoCuenta.Size = new System.Drawing.Size(82, 24);
            this.cbTipoCuenta.TabIndex = 1;
            this.cbTipoCuenta.SelectedIndexChanged += new System.EventHandler(this.cbTipoCuenta_SelectedIndexChanged);
            // 
            // cbCuenta
            // 
            this.cbCuenta.DropDownHeight = 900;
            this.cbCuenta.FormattingEnabled = true;
            this.cbCuenta.IntegralHeight = false;
            this.cbCuenta.Location = new System.Drawing.Point(92, 74);
            this.cbCuenta.Name = "cbCuenta";
            this.cbCuenta.Size = new System.Drawing.Size(189, 24);
            this.cbCuenta.TabIndex = 2;
            // 
            // tbCantidad
            // 
            this.tbCantidad.Location = new System.Drawing.Point(284, 74);
            this.tbCantidad.Name = "tbCantidad";
            this.tbCantidad.Size = new System.Drawing.Size(180, 22);
            this.tbCantidad.TabIndex = 3;
            this.tbCantidad.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gbAgregarCuentaAAsiento
            // 
            this.gbAgregarCuentaAAsiento.Controls.Add(this.textBox7);
            this.gbAgregarCuentaAAsiento.Controls.Add(this.textBox6);
            this.gbAgregarCuentaAAsiento.Controls.Add(this.textBox5);
            this.gbAgregarCuentaAAsiento.Controls.Add(this.textBox4);
            this.gbAgregarCuentaAAsiento.Controls.Add(this.textBox3);
            this.gbAgregarCuentaAAsiento.Controls.Add(this.btLimpiarAsiento);
            this.gbAgregarCuentaAAsiento.Controls.Add(this.btLimipiar);
            this.gbAgregarCuentaAAsiento.Controls.Add(this.btEliminar);
            this.gbAgregarCuentaAAsiento.Controls.Add(this.btActualizarCuenta);
            this.gbAgregarCuentaAAsiento.Controls.Add(this.rbHaber);
            this.gbAgregarCuentaAAsiento.Controls.Add(this.rbDebe);
            this.gbAgregarCuentaAAsiento.Controls.Add(this.tbCantidad);
            this.gbAgregarCuentaAAsiento.Controls.Add(this.btnAgregarCuenta);
            this.gbAgregarCuentaAAsiento.Controls.Add(this.cbCuenta);
            this.gbAgregarCuentaAAsiento.Controls.Add(this.cbTipoCuenta);
            this.gbAgregarCuentaAAsiento.Controls.Add(this.tbComentario);
            this.gbAgregarCuentaAAsiento.Controls.Add(this.tbNumAsiento);
            this.gbAgregarCuentaAAsiento.Location = new System.Drawing.Point(3, 89);
            this.gbAgregarCuentaAAsiento.Name = "gbAgregarCuentaAAsiento";
            this.gbAgregarCuentaAAsiento.Size = new System.Drawing.Size(553, 141);
            this.gbAgregarCuentaAAsiento.TabIndex = 8;
            this.gbAgregarCuentaAAsiento.TabStop = false;
            // 
            // btLimpiarAsiento
            // 
            this.btLimpiarAsiento.Location = new System.Drawing.Point(6, 104);
            this.btLimpiarAsiento.Name = "btLimpiarAsiento";
            this.btLimpiarAsiento.Size = new System.Drawing.Size(275, 31);
            this.btLimpiarAsiento.TabIndex = 17;
            this.btLimpiarAsiento.Text = "Limpiar Info de Asiento por Agregar";
            this.btLimpiarAsiento.UseVisualStyleBackColor = true;
            this.btLimpiarAsiento.Click += new System.EventHandler(this.btLimpiarAsiento_Click);
            // 
            // btLimipiar
            // 
            this.btLimipiar.Location = new System.Drawing.Point(444, 104);
            this.btLimipiar.Name = "btLimipiar";
            this.btLimipiar.Size = new System.Drawing.Size(105, 31);
            this.btLimipiar.TabIndex = 16;
            this.btLimipiar.Text = "Borrar todo";
            this.btLimipiar.UseVisualStyleBackColor = true;
            this.btLimipiar.Click += new System.EventHandler(this.btLimipiar_Click);
            // 
            // btEliminar
            // 
            this.btEliminar.Enabled = false;
            this.btEliminar.Location = new System.Drawing.Point(467, 18);
            this.btEliminar.Name = "btEliminar";
            this.btEliminar.Size = new System.Drawing.Size(80, 31);
            this.btEliminar.TabIndex = 15;
            this.btEliminar.Text = "Eliminar";
            this.btEliminar.UseVisualStyleBackColor = true;
            this.btEliminar.Click += new System.EventHandler(this.btEliminar_Click);
            // 
            // btActualizarCuenta
            // 
            this.btActualizarCuenta.Enabled = false;
            this.btActualizarCuenta.Location = new System.Drawing.Point(287, 18);
            this.btActualizarCuenta.Name = "btActualizarCuenta";
            this.btActualizarCuenta.Size = new System.Drawing.Size(178, 31);
            this.btActualizarCuenta.TabIndex = 14;
            this.btActualizarCuenta.Text = "Actualizar / Modificar";
            this.btActualizarCuenta.UseVisualStyleBackColor = true;
            this.btActualizarCuenta.Click += new System.EventHandler(this.btActualizarCuenta_Click);
            // 
            // rbHaber
            // 
            this.rbHaber.AutoSize = true;
            this.rbHaber.Location = new System.Drawing.Point(470, 78);
            this.rbHaber.Name = "rbHaber";
            this.rbHaber.Size = new System.Drawing.Size(68, 21);
            this.rbHaber.TabIndex = 9;
            this.rbHaber.Text = "Haber";
            this.rbHaber.UseVisualStyleBackColor = true;
            // 
            // rbDebe
            // 
            this.rbDebe.AutoSize = true;
            this.rbDebe.Checked = true;
            this.rbDebe.Location = new System.Drawing.Point(470, 59);
            this.rbDebe.Name = "rbDebe";
            this.rbDebe.Size = new System.Drawing.Size(63, 21);
            this.rbDebe.TabIndex = 8;
            this.rbDebe.TabStop = true;
            this.rbDebe.Text = "Debe";
            this.rbDebe.UseVisualStyleBackColor = true;
            // 
            // dgvCuentasT
            // 
            this.dgvCuentasT.AllowUserToAddRows = false;
            this.dgvCuentasT.AllowUserToDeleteRows = false;
            this.dgvCuentasT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dgvCuentasT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCuentasT.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCuentasT.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvCuentasT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCuentasT.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.dgvCuentasT.Location = new System.Drawing.Point(3, 434);
            this.dgvCuentasT.MultiSelect = false;
            this.dgvCuentasT.Name = "dgvCuentasT";
            this.dgvCuentasT.ReadOnly = true;
            this.dgvCuentasT.RowHeadersVisible = false;
            this.dgvCuentasT.RowTemplate.Height = 24;
            this.dgvCuentasT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCuentasT.Size = new System.Drawing.Size(553, 268);
            this.dgvCuentasT.TabIndex = 9;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 65.45455F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Cuenta";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 40F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Asiento";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewTextBoxColumn3.HeaderText = "Debe";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewTextBoxColumn4.HeaderText = "Haber";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.FillWeight = 40F;
            this.dataGridViewTextBoxColumn5.HeaderText = "Asiento";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // tbCuentasT
            // 
            this.tbCuentasT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbCuentasT.BackColor = System.Drawing.Color.Beige;
            this.tbCuentasT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbCuentasT.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCuentasT.Location = new System.Drawing.Point(3, 412);
            this.tbCuentasT.Name = "tbCuentasT";
            this.tbCuentasT.ReadOnly = true;
            this.tbCuentasT.Size = new System.Drawing.Size(553, 22);
            this.tbCuentasT.TabIndex = 10;
            this.tbCuentasT.Text = "Cuentas T";
            this.tbCuentasT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gbInfoGeneral
            // 
            this.gbInfoGeneral.Controls.Add(this.textBox10);
            this.gbInfoGeneral.Controls.Add(this.textBox9);
            this.gbInfoGeneral.Controls.Add(this.textBox8);
            this.gbInfoGeneral.Controls.Add(this.dtpFechaFin);
            this.gbInfoGeneral.Controls.Add(this.dtpFechaInicio);
            this.gbInfoGeneral.Controls.Add(this.tbEmpresa);
            this.gbInfoGeneral.Location = new System.Drawing.Point(3, -5);
            this.gbInfoGeneral.Name = "gbInfoGeneral";
            this.gbInfoGeneral.Size = new System.Drawing.Size(316, 99);
            this.gbInfoGeneral.TabIndex = 11;
            this.gbInfoGeneral.TabStop = false;
            // 
            // dtpFechaFin
            // 
            this.dtpFechaFin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaFin.Location = new System.Drawing.Point(177, 72);
            this.dtpFechaFin.Name = "dtpFechaFin";
            this.dtpFechaFin.Size = new System.Drawing.Size(133, 22);
            this.dtpFechaFin.TabIndex = 16;
            // 
            // dtpFechaInicio
            // 
            this.dtpFechaInicio.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaInicio.Location = new System.Drawing.Point(177, 43);
            this.dtpFechaInicio.Name = "dtpFechaInicio";
            this.dtpFechaInicio.Size = new System.Drawing.Size(133, 22);
            this.dtpFechaInicio.TabIndex = 14;
            // 
            // tbEmpresa
            // 
            this.tbEmpresa.Location = new System.Drawing.Point(80, 17);
            this.tbEmpresa.Name = "tbEmpresa";
            this.tbEmpresa.Size = new System.Drawing.Size(230, 22);
            this.tbEmpresa.TabIndex = 11;
            // 
            // tbEdoRes
            // 
            this.tbEdoRes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbEdoRes.BackColor = System.Drawing.Color.Beige;
            this.tbEdoRes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbEdoRes.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbEdoRes.Location = new System.Drawing.Point(562, 3);
            this.tbEdoRes.Name = "tbEdoRes";
            this.tbEdoRes.ReadOnly = true;
            this.tbEdoRes.Size = new System.Drawing.Size(766, 22);
            this.tbEdoRes.TabIndex = 13;
            this.tbEdoRes.Text = "Estado de Resultados";
            this.tbEdoRes.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dgvEdoResultados
            // 
            this.dgvEdoResultados.AllowUserToAddRows = false;
            this.dgvEdoResultados.AllowUserToDeleteRows = false;
            this.dgvEdoResultados.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvEdoResultados.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvEdoResultados.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvEdoResultados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEdoResultados.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.Column7});
            this.dgvEdoResultados.Location = new System.Drawing.Point(562, 25);
            this.dgvEdoResultados.MultiSelect = false;
            this.dgvEdoResultados.Name = "dgvEdoResultados";
            this.dgvEdoResultados.ReadOnly = true;
            this.dgvEdoResultados.RowHeadersVisible = false;
            this.dgvEdoResultados.RowTemplate.Height = 24;
            this.dgvEdoResultados.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEdoResultados.Size = new System.Drawing.Size(766, 205);
            this.dgvEdoResultados.TabIndex = 12;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.FillWeight = 150F;
            this.dataGridViewTextBoxColumn7.HeaderText = "Descripcion";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewTextBoxColumn8.HeaderText = "Cantidad";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn9.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewTextBoxColumn9.HeaderText = "Total";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Column7
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.Column7.DefaultCellStyle = dataGridViewCellStyle9;
            this.Column7.FillWeight = 30F;
            this.Column7.HeaderText = "%";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // tbBalGral
            // 
            this.tbBalGral.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbBalGral.BackColor = System.Drawing.Color.Beige;
            this.tbBalGral.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbBalGral.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbBalGral.Location = new System.Drawing.Point(562, 232);
            this.tbBalGral.Name = "tbBalGral";
            this.tbBalGral.ReadOnly = true;
            this.tbBalGral.Size = new System.Drawing.Size(766, 22);
            this.tbBalGral.TabIndex = 15;
            this.tbBalGral.Text = "Balance General";
            this.tbBalGral.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dgvBalanceGeneral
            // 
            this.dgvBalanceGeneral.AllowUserToAddRows = false;
            this.dgvBalanceGeneral.AllowUserToDeleteRows = false;
            this.dgvBalanceGeneral.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvBalanceGeneral.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvBalanceGeneral.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvBalanceGeneral.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBalanceGeneral.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16});
            this.dgvBalanceGeneral.Location = new System.Drawing.Point(562, 254);
            this.dgvBalanceGeneral.MultiSelect = false;
            this.dgvBalanceGeneral.Name = "dgvBalanceGeneral";
            this.dgvBalanceGeneral.ReadOnly = true;
            this.dgvBalanceGeneral.RowHeadersVisible = false;
            this.dgvBalanceGeneral.RowTemplate.Height = 24;
            this.dgvBalanceGeneral.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBalanceGeneral.Size = new System.Drawing.Size(766, 244);
            this.dgvBalanceGeneral.TabIndex = 14;
            // 
            // dataGridViewTextBoxColumn13
            // 
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridViewTextBoxColumn13.DefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridViewTextBoxColumn13.FillWeight = 150F;
            this.dataGridViewTextBoxColumn13.HeaderText = "Descripcion";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn14
            // 
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn14.DefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridViewTextBoxColumn14.FillWeight = 99.49239F;
            this.dataGridViewTextBoxColumn14.HeaderText = "Cantidad";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn15
            // 
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn15.DefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridViewTextBoxColumn15.FillWeight = 99.49239F;
            this.dataGridViewTextBoxColumn15.HeaderText = "Total";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewTextBoxColumn16
            // 
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.dataGridViewTextBoxColumn16.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewTextBoxColumn16.FillWeight = 30F;
            this.dataGridViewTextBoxColumn16.HeaderText = "%";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            // 
            // tbRazonesFinancieras
            // 
            this.tbRazonesFinancieras.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbRazonesFinancieras.BackColor = System.Drawing.Color.Beige;
            this.tbRazonesFinancieras.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRazonesFinancieras.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbRazonesFinancieras.Location = new System.Drawing.Point(562, 504);
            this.tbRazonesFinancieras.Name = "tbRazonesFinancieras";
            this.tbRazonesFinancieras.ReadOnly = true;
            this.tbRazonesFinancieras.Size = new System.Drawing.Size(766, 22);
            this.tbRazonesFinancieras.TabIndex = 17;
            this.tbRazonesFinancieras.Text = "Razones Financieras";
            this.tbRazonesFinancieras.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btImprimirTexto
            // 
            this.btImprimirTexto.BackColor = System.Drawing.Color.DarkKhaki;
            this.btImprimirTexto.Location = new System.Drawing.Point(470, 67);
            this.btImprimirTexto.Name = "btImprimirTexto";
            this.btImprimirTexto.Size = new System.Drawing.Size(82, 28);
            this.btImprimirTexto.TabIndex = 16;
            this.btImprimirTexto.Text = "A Texto";
            this.btImprimirTexto.UseVisualStyleBackColor = false;
            this.btImprimirTexto.Click += new System.EventHandler(this.btImprimirTexto_Click);
            // 
            // btEjemplo
            // 
            this.btEjemplo.BackColor = System.Drawing.Color.DarkKhaki;
            this.btEjemplo.Location = new System.Drawing.Point(325, 3);
            this.btEjemplo.Name = "btEjemplo";
            this.btEjemplo.Size = new System.Drawing.Size(82, 28);
            this.btEjemplo.TabIndex = 18;
            this.btEjemplo.Text = "Ejemplo";
            this.btEjemplo.UseVisualStyleBackColor = false;
            this.btEjemplo.Click += new System.EventHandler(this.btEjemplo_Click);
            // 
            // btInfo
            // 
            this.btInfo.Location = new System.Drawing.Point(325, 37);
            this.btInfo.Name = "btInfo";
            this.btInfo.Size = new System.Drawing.Size(82, 28);
            this.btInfo.TabIndex = 19;
            this.btInfo.Text = "Info";
            this.btInfo.UseVisualStyleBackColor = true;
            this.btInfo.Click += new System.EventHandler(this.btInfo_Click);
            // 
            // btAbrirContaCostos
            // 
            this.btAbrirContaCostos.Location = new System.Drawing.Point(325, 67);
            this.btAbrirContaCostos.Name = "btAbrirContaCostos";
            this.btAbrirContaCostos.Size = new System.Drawing.Size(142, 28);
            this.btAbrirContaCostos.TabIndex = 20;
            this.btAbrirContaCostos.Text = "Abrir Conta. Costos";
            this.btAbrirContaCostos.UseVisualStyleBackColor = true;
            this.btAbrirContaCostos.Click += new System.EventHandler(this.btAbrirContaCostos_Click);
            // 
            // dgvRazonesFinancieras
            // 
            this.dgvRazonesFinancieras.AllowUserToAddRows = false;
            this.dgvRazonesFinancieras.AllowUserToDeleteRows = false;
            this.dgvRazonesFinancieras.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvRazonesFinancieras.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvRazonesFinancieras.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRazonesFinancieras.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21});
            this.dgvRazonesFinancieras.Location = new System.Drawing.Point(562, 526);
            this.dgvRazonesFinancieras.MultiSelect = false;
            this.dgvRazonesFinancieras.Name = "dgvRazonesFinancieras";
            this.dgvRazonesFinancieras.ReadOnly = true;
            this.dgvRazonesFinancieras.RowHeadersVisible = false;
            this.dgvRazonesFinancieras.RowTemplate.Height = 24;
            this.dgvRazonesFinancieras.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRazonesFinancieras.Size = new System.Drawing.Size(766, 176);
            this.dgvRazonesFinancieras.TabIndex = 21;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.FillWeight = 80F;
            this.dataGridViewTextBoxColumn19.HeaderText = "Tipo";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.FillWeight = 136.435F;
            this.dataGridViewTextBoxColumn20.HeaderText = "Descripcion";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn21
            // 
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn21.DefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridViewTextBoxColumn21.FillWeight = 60F;
            this.dataGridViewTextBoxColumn21.HeaderText = "Valor";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // tbInventarioFinal
            // 
            this.tbInventarioFinal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbInventarioFinal.Location = new System.Drawing.Point(413, 383);
            this.tbInventarioFinal.Name = "tbInventarioFinal";
            this.tbInventarioFinal.Size = new System.Drawing.Size(143, 22);
            this.tbInventarioFinal.TabIndex = 22;
            this.tbInventarioFinal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbInventarioInicial
            // 
            this.tbInventarioInicial.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbInventarioInicial.Location = new System.Drawing.Point(220, 383);
            this.tbInventarioInicial.Name = "tbInventarioInicial";
            this.tbInventarioInicial.Size = new System.Drawing.Size(143, 22);
            this.tbInventarioInicial.TabIndex = 25;
            this.tbInventarioInicial.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox1.BackColor = System.Drawing.SystemColors.Control;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(3, 386);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(211, 15);
            this.textBox1.TabIndex = 26;
            this.textBox1.Text = "VALOR DE INVENTARIO:     Inicial:";
            // 
            // textBox2
            // 
            this.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox2.BackColor = System.Drawing.SystemColors.Control;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(374, 386);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(38, 15);
            this.textBox2.TabIndex = 27;
            this.textBox2.Text = "Final:";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.Control;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(6, 56);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(76, 15);
            this.textBox3.TabIndex = 28;
            this.textBox3.Text = "Cuenta Tipo";
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.SystemColors.Control;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(95, 56);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(122, 15);
            this.textBox4.TabIndex = 29;
            this.textBox4.Text = "Nombre de Cuenta";
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.SystemColors.Control;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(284, 56);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(76, 15);
            this.textBox5.TabIndex = 30;
            this.textBox5.Text = "Cantidad";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.Control;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(95, 11);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(76, 15);
            this.textBox6.TabIndex = 31;
            this.textBox6.Text = "Comentario";
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.Control;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(6, 11);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(76, 15);
            this.textBox7.TabIndex = 32;
            this.textBox7.Text = "No. Asiento";
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.SystemColors.Control;
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(13, 21);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(61, 15);
            this.textBox8.TabIndex = 33;
            this.textBox8.Text = "Empresa";
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.SystemColors.Control;
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(13, 48);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(153, 15);
            this.textBox9.TabIndex = 33;
            this.textBox9.Text = "Fecha de Balance Inicial";
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.SystemColors.Control;
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(13, 75);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(153, 15);
            this.textBox10.TabIndex = 34;
            this.textBox10.Text = "Fecha de Balance Final";
            // 
            // FormContabilidadGeneral
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1332, 705);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.tbInventarioInicial);
            this.Controls.Add(this.tbInventarioFinal);
            this.Controls.Add(this.dgvRazonesFinancieras);
            this.Controls.Add(this.btAbrirContaCostos);
            this.Controls.Add(this.btInfo);
            this.Controls.Add(this.btEjemplo);
            this.Controls.Add(this.btImprimirTexto);
            this.Controls.Add(this.tbRazonesFinancieras);
            this.Controls.Add(this.tbBalGral);
            this.Controls.Add(this.dgvBalanceGeneral);
            this.Controls.Add(this.tbEdoRes);
            this.Controls.Add(this.dgvEdoResultados);
            this.Controls.Add(this.gbInfoGeneral);
            this.Controls.Add(this.tbCuentasT);
            this.Controls.Add(this.dgvCuentasT);
            this.Controls.Add(this.gbAgregarCuentaAAsiento);
            this.Controls.Add(this.dgvAsientosContables);
            this.Controls.Add(this.btnCalcular);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormContabilidadGeneral";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Contabilidad a partir de Asientos Contables";
            ((System.ComponentModel.ISupportInitialize)(this.dgvAsientosContables)).EndInit();
            this.gbAgregarCuentaAAsiento.ResumeLayout(false);
            this.gbAgregarCuentaAAsiento.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCuentasT)).EndInit();
            this.gbInfoGeneral.ResumeLayout(false);
            this.gbInfoGeneral.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEdoResultados)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBalanceGeneral)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRazonesFinancieras)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAgregarCuenta;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.DataGridView dgvAsientosContables;
        private System.Windows.Forms.TextBox tbNumAsiento;
        private System.Windows.Forms.TextBox tbComentario;
        private System.Windows.Forms.ComboBox cbTipoCuenta;
        private System.Windows.Forms.ComboBox cbCuenta;
        private System.Windows.Forms.TextBox tbCantidad;
        private System.Windows.Forms.GroupBox gbAgregarCuentaAAsiento;
        private System.Windows.Forms.Button btEliminar;
        private System.Windows.Forms.Button btActualizarCuenta;
        private System.Windows.Forms.RadioButton rbHaber;
        private System.Windows.Forms.RadioButton rbDebe;
        private System.Windows.Forms.DataGridView dgvCuentasT;
        private System.Windows.Forms.TextBox tbCuentasT;
        private System.Windows.Forms.GroupBox gbInfoGeneral;
        private System.Windows.Forms.DateTimePicker dtpFechaFin;
        private System.Windows.Forms.DateTimePicker dtpFechaInicio;
        private System.Windows.Forms.TextBox tbEmpresa;
        private System.Windows.Forms.TextBox tbEdoRes;
        private System.Windows.Forms.DataGridView dgvEdoResultados;
        private System.Windows.Forms.TextBox tbBalGral;
        private System.Windows.Forms.DataGridView dgvBalanceGeneral;
        private System.Windows.Forms.TextBox tbRazonesFinancieras;
        private System.Windows.Forms.Button btImprimirTexto;
        private System.Windows.Forms.Button btEjemplo;
        private System.Windows.Forms.Button btInfo;
        private System.Windows.Forms.Button btAbrirContaCostos;
        private System.Windows.Forms.DataGridView dgvRazonesFinancieras;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.TextBox tbInventarioFinal;
        private System.Windows.Forms.TextBox tbInventarioInicial;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.Button btLimpiarAsiento;
        private System.Windows.Forms.Button btLimipiar;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
    }
}

